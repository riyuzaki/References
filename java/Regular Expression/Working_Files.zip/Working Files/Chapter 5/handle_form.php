<DOCTYPE html>

<html>

<head>

<title>Form Feedback</title>

</head>

<body>

<?php

$name = $_REQUEST['name'];

$web = $_REQUEST['web'];

$pattern = '/^(https|ftp):\/\/[a-z0-9-]+(\.[a-z0-9-]+)+$/';

if (preg_match($pattern, $web)) {
   echo "<p>Thank You, <b>$name.</b>
   <p>We will look you up at
   <i>$web</i>.</p>\n";
}
else {
   echo "<p>Your web site, <em>$web</em>, is invalid.</p>";
}

?>

</body>

</html>
