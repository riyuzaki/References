import java.io.*;
import java.util.regex.*;

public class StripTags {
   public static void main(String[] args) throws IOException {
      BufferedReader bf = new BufferedReader(new FileReader("tags.html"));
      String line, lines;
      lines = "";
      while ((line = bf.readLine()) != null) {
         lines += line;
      }
      String[] stripped = lines.split("<[^<>]*>");
      for (int i = 0; i < stripped.length; ++i) {
         System.out.println(stripped[i]);
      }
   }
}