using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ValidPath
{
    class Program
    {
        static void Main(string[] args)
        {
            Regex reg = new Regex(@"^[a-z]:\\(?:[^\\/:*?""<>|\r\n]+\\)*[^\\/:*?""<>|\r\n]*$");
            string path;
            Console.Write("Enter a path:");
            path = Console.ReadLine();
            if (reg.IsMatch(path)) 
            {
                Console.WriteLine("Valid path");
            }
            else
            {
                Console.WriteLine("Invalid path");
            }
            Console.ReadKey();
        }
    }
}
