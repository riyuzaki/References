var list = read("names.txt");
var names = list.split(",");
var pattern = /(\w+)\s(\w+)/;
for (var i = 0; i < names.length; ++i) {
   print(names[i]);
   var name = names[i].replace(pattern, "$2, $1");
   print(name);
}