<html>
<body>
<form method="POST" action="<?php echo $_SERVER['PHP_SELF'];?>">
Enter your social security number: <br/>
<input type = "text" name = "ssn"><br/>
<input type = "submit" name = "Submit">
</form>
<?php
   $ssn = $_POST['ssn'];
   $pattern = "/\b(\d{3})(\d{2})(\d{4})\b/";
   $replacement = "$1-$2-$3";
   $ssn = preg_replace($pattern, $replacement, $ssn);
   echo $ssn;
?>
</body>
</html>