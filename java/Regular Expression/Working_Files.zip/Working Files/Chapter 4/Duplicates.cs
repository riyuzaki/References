using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace duplicates
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader lines;
            lines = File.OpenText("c:\\data\\dups.txt");
            string line;
            Regex reg = new Regex(@"\b([a-z]+)\s+\1\b");
            while (!lines.EndOfStream)
            {
                line = lines.ReadLine();
                line = reg.Replace(line, "$1");
                Console.WriteLine(line);
                
                
                
            }
            Console.ReadKey();
        }
    }
}
