using System.Text;
using System.Text.RegularExpressions;

namespace Spelling
{
    class Program
    {
        static void Main(string[] args)
        {
            String words = "";
            Console.Write("Enter a list of words: ");
            words = Console.ReadLine();
            Regex regex = new Regex("eing");
            MatchCollection matches = regex.Matches(words);
            foreach (Match aMatch in matches)
            {
                Console.WriteLine(aMatch.ToString());
            }
            Console.ReadKey();
        }
    }
}
