using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Example
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "var x = 100;";
            Regex reg = new Regex("var");
            MatchCollection matches = reg.Matches(str);
            foreach (Match aMatch in matches)
            {
                Console.WriteLine(aMatch.ToString());
            }
            Console.ReadKey();
        }
    }
}
