using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace Zipcodes
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader zipcodes;
            zipcodes = File.OpenText("c:\\data\\zipcodes.txt");
            string zip;
            Regex reg = new Regex("^[0-9]{5}(?:-[0-9]{4})?$");
            while (!zipcodes.EndOfStream)
            {
                zip = zipcodes.ReadLine();
                Match aMatch = reg.Match(zip);
                Console.WriteLine(aMatch.ToString());
            }
            Console.ReadKey();
        }
    }
}
