

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML
1.0 Transitional//EN" "http://www.w3.org/
TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml"
xml:lang="en" lang="en">

<meta http-equiv="content-type"content=
"text/html; charset=iso-8859-1" />

<title>Form Feedback</title>

</head>

<body>

<?php

$name = $_REQUEST['name'];

$email = $_REQUEST['email'];

$pattern = "/\S+@\S+?/";

if (preg_match($pattern, $email)) {
   echo "<p>Thank You, <b>$name.</b>
   <p>We will reply to you at
   <i>$email</i>.</p>\n";
}
else {
   echo "<p>Your email address, <em>$email</em>, is invalid.</p>";
}

?>

</body>

</html>
