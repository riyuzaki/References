using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace Zipcodes
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader ips;
            ips = File.OpenText("c:\\data\\ip.txt");
            string ip;
            Regex reg = new Regex(@"^([0-9]{1,3}\.){3}[0-9]{1,3}$");
            while (!ips.EndOfStream)
            {
                ip = ips.ReadLine();
                Match aMatch = reg.Match(ip);
                Console.WriteLine(aMatch.ToString());
            }
            Console.ReadKey();
        }
    }
}
