using System;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace duplicates
{
    class Program
    {
        static void Main(string[] args)
        {
            StreamReader infile;
            infile = File.OpenText("c:\\data\\text.txt");
            string lines;
            lines = infile.ReadToEnd();
            Console.WriteLine(lines);
            Regex reg = new Regex(@"(?i)THE");
            MatchCollection matches = reg.Matches(lines);
            if (matches.Count > 0)
            {
                Console.WriteLine("Found -the- " + matches.Count + " times.");
            }
            else
            {
                Console.WriteLine("Didn't find -the-.");
            }
            Console.ReadKey();
        }
    }
}
