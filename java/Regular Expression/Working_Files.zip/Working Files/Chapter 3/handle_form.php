<DOCTYPE html>

<html>

<head>

<title>Form Feedback</title>

</head>

<body>

<?php

$name = $_REQUEST['name'];

$email = $_REQUEST['email'];

$date = $_REQUEST['date'];

$pattern = '/^(1[0-2]|0[1-9])\/(3[01]|[12][0-9]|0[1-9])\/[0-9]{4}/';

if (preg_match($pattern, $date)) {
   echo "<p>Thank You, <b>$name.</b>
   <p>We will reply to you at
   <i>$email</i>.</p>\n";
}
else {
   echo "<p>Your date, <em>$date</em>, is invalid.</p>";
}

?>

</body>

</html>
